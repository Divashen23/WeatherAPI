package com.divashennarainsamy.weatherapi;

import androidx.appcompat.app.AppCompatActivity;

import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;

import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private final String TAG = "accuweatherURL";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        URL accuweatherURL = NetworkUtil.buildURL();
        Log.i(TAG, "onCreate: " + accuweatherURL);
    }
}